# Puja Finance Manager

Android WebView app for managing Puja subscriptions, income and expenses.

## GitHub APK build

1. Upload the contents of this project to the repository root.
2. Open **Actions**.
3. Select **Build Puja Finance Manager APK**.
4. Tap **Run workflow**.
5. When it finishes successfully, open the workflow run and download the artifact:
   **Puja-Finance-Manager-debug-apk**

The build is configured for Java 17 and Android Gradle Plugin 8.6.1.

The project also excludes the old Kotlin `kotlin-stdlib-jdk7` / `kotlin-stdlib-jdk8`
modules that can cause duplicate-class errors with newer Kotlin standard library
versions.
