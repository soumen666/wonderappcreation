# Puja Finance Manager — GitHub APK Build

This repository is an Android WebView wrapper around the professional Puja Finance Manager UI.

## Phone-only build
1. Upload the CONTENTS of this folder to the root of a GitHub repository.
2. Open Actions.
3. Select "Build Puja Finance Manager APK".
4. Tap "Run workflow".
5. Download the "Puja-Finance-Manager-debug-apk" artifact.

The embedded web app uses browser DOM/local storage, which is retained by the Android WebView app for local device data.
