# Puja Finance Manager — Android APK project

This is a ready-to-build Android project containing the approved v9 mobile UI.

## Local storage
The app is a native Android WebView wrapper around the supplied HTML application. JavaScript DOM storage is enabled, so the application's localStorage is persisted in the Android app's private storage. Financial records therefore remain on the phone and do not require Firebase.

## Build without a laptop
Upload this entire folder to a GitHub repository. The included GitHub Actions workflow builds `app-debug.apk` automatically. In GitHub, open **Actions → Build Puja Finance Manager APK → Run workflow**. When finished, download the artifact named `Puja-Finance-Manager-debug-apk`.

The debug APK is intended for direct testing/sharing. For Play Store distribution, create a signed release APK/AAB with a private signing key.
